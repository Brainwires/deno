// A prebuilt-binary install as prebuild-install does it: a download from
// GitHub's release hosts through the proxy the environment names. The probe
// asks the jail's proxy for a tunnel to a host and records whether the
// proxy's allow-list refused it (any other answer, a connection or a
// resolution failure offline, means the host was allowed). Then it fails,
// as a build would without a compiler, so the installer prints its hint.
const fs = require("node:fs");
const net = require("node:net");
const path = require("node:path");

function attempt(host) {
  const proxy = process.env.HTTPS_PROXY || process.env.https_proxy;
  if (!proxy) return Promise.resolve("no network");
  const { hostname, port } = new URL(proxy);
  return new Promise((resolve) => {
    const socket = net.connect(Number(port), hostname, () => {
      socket.write(`CONNECT ${host}:443 HTTP/1.1\r\nHost: ${host}:443\r\n\r\n`);
    });
    let data = "";
    socket.setTimeout(20000, () => {
      socket.destroy();
      resolve(data.includes("allow-list") ? "denied" : "allowed");
    });
    socket.on("data", (chunk) => {
      data += chunk;
      if (data.includes("\r\n\r\n")) {
        socket.destroy();
        resolve(data.includes("allow-list") ? "denied" : "allowed");
      }
    });
    socket.on("error", () => resolve("denied"));
    socket.on("close", () =>
      resolve(data.includes("allow-list") ? "denied" : "allowed")
    );
  });
}

(async () => {
  const github = await attempt("github.com");
  const other = await attempt("example.com");
  fs.writeFileSync(
    path.join(__dirname, "results.txt"),
    `github.com: ${github}\nexample.com: ${other}\n`,
  );
  process.exit(1);
})();
