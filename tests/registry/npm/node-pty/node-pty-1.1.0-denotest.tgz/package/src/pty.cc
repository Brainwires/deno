// A stand-in for node-pty's addon: a Node-API module named `pty` with one
// function, `fork`, as the real addon's entry points are called.
#include <node_api.h>

namespace pty_stand_in {

napi_value Fork(napi_env env, napi_callback_info args) {
  napi_value result;
  napi_status status = napi_create_string_utf8(
      env, "the addon's fork", NAPI_AUTO_LENGTH, &result);
  if (status != napi_ok) return nullptr;
  return result;
}

napi_value init(napi_env env, napi_value exports) {
  napi_value fn;
  napi_status status = napi_create_function(env, nullptr, 0, Fork, nullptr, &fn);
  if (status != napi_ok) return nullptr;
  status = napi_set_named_property(env, exports, "fork", fn);
  if (status != napi_ok) return nullptr;
  return exports;
}

NAPI_MODULE(NODE_GYP_MODULE_NAME, init)

}  // namespace pty_stand_in
