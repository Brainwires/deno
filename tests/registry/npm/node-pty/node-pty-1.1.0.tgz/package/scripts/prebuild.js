// node-pty checks for a prebuilt addon here and exits 1 without one
process.exit(1);
