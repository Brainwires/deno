// node-pty cleans its build folder here
